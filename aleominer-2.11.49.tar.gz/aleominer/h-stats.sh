#!/usr/bin/env bash
source $MINER_DIR/$CUSTOM_MINER/h-manifest.conf

algo='aleo'
version="2.11.49"
stats=""
unit="S/s"
khs=0
hs=()
temp=()
fan=()
numbers=()

khs=$(cat /root/hive/miners/custom/aleominer/aleominer1.log |grep "Speed(S/s)" | awk 'END {print}'| awk '{print $3}')
khs=$(echo "scale=5; $khs / 1000" | bc)

khs_num=$(echo "$khs" | jq -R . | jq -s 'map(tonumber)[0]')

if [[ "$retime" =~ ^[0-9]+$ ]]; then
	if [ "$uptime" -gt "$retime" ]; then
		miner restart
		exit 0
	fi

fi

stats=$(jq -nc --argjson khs "$khs_num" \
	--arg uptime "$uptime" \
	--arg hs_units "$unit" \
	--arg ver "$version" \
	--arg algo "$algo" \
	'{$uptime, "hs_units":$hs_units, "ver":$ver, "algo":$algo, "khs":$khs}')

echo "$stats"
